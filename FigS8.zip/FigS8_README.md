# Supplementary Figure S8 — Variation partitioning at the metabolite-category level

Code and data to reproduce **Supplementary Figure S8**: the same dbRDA + **variation
partitioning** analysis as Figure 2, but with the metabolome collapsed into five
**metabolite categories** (phosphate, carbohydrate, amino acid, SCFAs, others) instead of
the ~339 individual compounds. It shows how much microbiome variation is explained by
Species, Treatment, and the broad metabolite-category block.

The analysis script (`Fig2_dbRDA_varpart_fixed.R`) is **identical** to the one in the
Figure 2 bundle; only the chemistry input differs (categories here vs. individual
metabolites in Fig. 2).

> ⚠️ **Missing input — please add before running.** `Fig2_dbRDA_varpart_fixed.R` needs the
> sample metadata **`List.csv`** as its first argument, which is **not included in this
> bundle**. It is the same 24-sample `List.csv` used for Figure 2 (`sample`, `cnd`, `env`);
> copy it into the zip.

---

## Contents

| File | Role |
|------|------|
| *`List.csv`* | **(required, not included)** sample metadata: `sample`, `cnd` (treatment), `env` (host species). Same file as Fig. 2. |
| `B_Genus_bacdata.csv` | Genus-level microbiome table (samples × 207 genera). |
| `Chemical_Category_data.csv` | Metabolite-category table: 5 categories (phosphate, carbohydrate, amino acid, SCFAs, others). |
| `output_chemical_category_log_Z.csv` | Pre-computed log→z of the category table (`*_log_Z` columns). Ready-to-use input for the R script. |
| `metabolite_transform.py` | Regenerates `output_chemical_category_log_Z.csv` from `Chemical_Category_data.csv` if needed. |
| `Fig2_dbRDA_varpart_fixed.R` | NMDS + PERMANOVA + dbRDA + variation partitioning (same script as Fig. 2). |
| `plot_ordination_animal_fixnew.py` | Draws the dbRDA / NMDS ordination. |
| `Variation_Venn_animal_fixed.py` | Draws the variation-partitioning Venn diagram and bar chart. |

**Groups.** `env` ∈ {Fish, Chicken, Pig}; `cnd` ∈ {`con` = Control, `Tst` = Compost}.
The first column of every data table is the sample ID and must be in the **same row order**
as `List.csv` (matching is by position, so the differing ID text in
`Chemical_Category_data.csv`, e.g. `FE-control 1`, does not matter).

---

## Requirements

**R (≥ 4.0)**

```r
install.packages("vegan")
```

**Python (≥ 3.8)**

```bash
pip install pandas numpy matplotlib seaborn scipy matplotlib-venn
```

---

## Reproduce Figure S8

Run these in a working directory **separate from the Fig. 2 run**, because the R script
writes to `results_vp_microbiome/` and would otherwise overwrite the Fig. 2 outputs.

### Step 0 — (optional) regenerate the category log→z table

The transformed table is already provided; regenerate it only if you change the raw data:

```bash
python metabolite_transform.py Chemical_Category_data.csv output_chemical_category_log_Z.csv --mode log_Z
```

### Step 1 — dbRDA + Variation Partitioning (R)

```bash
Rscript Fig2_dbRDA_varpart_fixed.R List.csv B_Genus_bacdata.csv output_chemical_category_log_Z.csv --response microbiome
```

Results go to `results_vp_microbiome/`, including:

- `vp_variance.csv` + `variation_partitioning.pdf` → **Fig. S8 panel data**
- `dbRDA_sites.csv` (`CAP1`, `CAP2`), `dbRDA_vectors.csv`, `dbRDA_variance.csv`
- `NMDS_scores.csv`, `adonis_species_treatment.csv`, `pairwise_species_permanova.csv`
- `Fig1_summary.txt`

### Step 2 — Plot variation partitioning (Python)

```bash
python Variation_Venn_animal_fixed.py results_vp_microbiome/vp_variance.csv
```

Writes a Venn diagram, bar chart, combined figure and a cleaned CSV to
`variation_partitioning_output/`. Negative adjusted R² values are clamped to 0 for display
and flagged. Adjust size with `-w/--width` and `--height`.

### Step 3 — (optional) Plot the ordination (Python)

```bash
python plot_ordination_animal_fixnew.py results_vp_microbiome/dbRDA_sites.csv CAP1 CAP2
```

Figures are written to `ordination_output/` (colour = host species, marker/ellipse =
treatment).

---

## Method notes

- With only 5 category variables (vs. 24 samples), the dbRDA is not overfitted; forward
  selection simply keeps the informative categories.
- **Category preprocessing:** log→standard z-score in Python (`--mode log_Z`); the R script
  reads the `*_log_Z` columns directly.
- **Label note:** the shared R script labels the third block "Metabolite" internally, so
  `vp_variance.csv` fraction names read `Metabolite`, `Species:Metabolite`, etc. The
  Venn/bar script auto-detects and uses that label. Rename to "Category" in the CSV (or the
  figure) if you prefer that wording for the supplement.
- `set.seed(123)` is set before NMDS and permutation tests, so results are reproducible.

---

## Citation

If you use this code or data, please cite:

> *[Author(s), Year. Title. Journal.]*  <!-- TODO: fill in -->

## License

<!-- TODO: choose a license, e.g. MIT -->
