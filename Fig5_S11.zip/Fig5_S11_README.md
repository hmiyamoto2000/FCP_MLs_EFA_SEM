# Figure 5 & Supplementary S11 — Bayesian group-importance of four metabolites

Code and data to reproduce **Figure 5** and its supplementary diagnostics (**S11**). The
analysis asks a single question: **does the compost treatment move the four universally
responsive metabolites as a group?** The four metabolites are 2-Aminoisobutyric acid
(AIB), Threitol (Thr), Butyrate (But) and 5-Methoxytryptamine (MeOT).

A Bayesian multivariate regression (`blavaan::bsem`, Stan backend) models the four
metabolites jointly against treatment (Control vs. Compost), with free residual
covariances. From the posterior it derives a **group separation score** (Mahalanobis), a
**multivariate R²**, **per-metabolite effects** (probability of direction + ROPE), and an
**association network** (treatment→metabolite arrows; metabolite–metabolite partial
correlations, undirected). Metabolite-to-metabolite direction is deliberately **not
asserted** — only the group-level treatment effect is claimed.

---

## Contents

| File | Role |
|------|------|
| `List.csv` | Sample metadata: `sample`, `cnd` (treatment), `env` (host species). 24 samples (12 per group, 3 species). |
| `Chemical_data.csv` | Raw metabolite table; the four target metabolites are selected by name. |
| `Fig5_bayes_4met.R` | **Main analysis.** Fits the Bayesian multivariate model and writes all `bayes_*.csv` posterior summaries + diagnostics. |
| `Fig5_network_assoc_4met.R` | Draws the association network from `bayes_network_edges.csv`. |
| `plot_fig5_forest_4met_tall.py` | **Figure 5 (main):** group-separation score + multivariate R² (top) and per-metabolite forest (bottom). |
| `plot_fig5_bayes_4met.py` | Extended 4-panel Bayesian figure (posterior of separation, forest, R², per-species consistency). |
| `make_diagnostics_table.py` | Builds the S11 diagnostics table (CSV + Word `.docx`) from the diagnostics CSVs. |
| `Bayes_procedure.rtf` | Short run-order note. |
| `output_matabolite_log_Z.csv` | Pre-transformed metabolite table — **not used by this figure's pipeline** (the R script reads the raw `Chemical_data.csv`). Included for reference only; can be omitted. |

**Groups.** `env` ∈ {Fish, Chicken, Pig}; `cnd` ∈ {`con` = Control, `Tst` = Compost}.

---

## Requirements

**R (≥ 4.0), with a working Stan backend.** `blavaan` compiles models through Stan, so a
C++ toolchain and `rstan` (or CmdStan) must be installed and working first — this is the
heaviest dependency here.

```r
install.packages(c("blavaan", "loo", "future", "rstan", "posterior"))
# network diagram:
install.packages(c("DiagrammeR", "DiagrammeRsvg", "rsvg"))
```

**Python (≥ 3.8)**

```bash
pip install numpy pandas matplotlib
pip install python-docx     # optional: enables the Word .docx diagnostics table
```

---

## Reproduce Figure 5 & S11

> **Output-directory note.** `Fig5_bayes_4met.R` writes its results to **`SEM_result/`**
> (hard-coded). The downstream scripts take that directory as an argument, so the simplest
> path is to pass `SEM_result/` to each of them, as shown below. (If you prefer the name
> `bayes4_result` used in `Bayes_procedure.rtf`, edit the `outdir` line near the top of
> `Fig5_bayes_4met.R` and use that name everywhere instead.)

### Step 1 — Fit the Bayesian model (R)

```bash
Rscript Fig5_bayes_4met.R List.csv Chemical_data.csv
```

Runs 4 MCMC chains (2000 warmup + 2000 sampling each), so expect a few minutes plus
one-time Stan compilation. Writes to `SEM_result/`:

- `bayes_group_scores.csv` — group separation (Mahalanobis), bundled-effect norm, multivariate R²
- `bayes_effects.csv`, `bayes_pd_rope.csv` — per-metabolite effects (median, CrI/HDI, pd, ROPE)
- `bayes_posterior_draws.csv` — draws for the histograms
- `bayes_species_separation.csv` — within-species separation
- `bayes_network_edges.csv` — edges for the association network
- `bayes_loo.csv/.txt`, `bayes_diagnostics_full.csv`, `bayes_summary.txt` — LOO + convergence diagnostics

### Step 2 — Figure 5, main (Python)

```bash
python plot_fig5_forest_4met_tall.py SEM_result/
```

Writes `SEM_result/figures/Fig5_forest.pdf/png`.

### Step 3 — Extended 4-panel figure (Python)

```bash
python plot_fig5_bayes_4met.py SEM_result/
```

Writes `SEM_result/figures/Fig5_bayes.pdf/png`.

### Step 4 — Association network (R)

```bash
Rscript Fig5_network_assoc_4met.R SEM_result/bayes_network_edges.csv
```

Writes `SEM_result/Fig5_assoc_network.pdf/png`. Solid edges = 95% CrI excludes 0; dashed =
includes 0. Green = positive, pink = negative. Arrows only on treatment→metabolite edges
(justified by randomization); metabolite–metabolite edges are undirected partial
correlations.

### Step 5 — S11 diagnostics table (Python)

```bash
python make_diagnostics_table.py SEM_result/
```

Writes `SEM_result/TableS_diagnostics.csv`, `TableS_effects.csv`, and (if `python-docx` is
installed) `TableS_diagnostics.docx`.

---

## Method notes

- **Metabolite selection & scaling:** the four metabolites are matched by name in
  `Chemical_data.csv`, `log1p`-transformed, then standardized **within each host species**
  so cross-species scale differences don't drive the estimate.
- **What is (and isn't) claimed:** only the group-level treatment effect is asserted.
  Per-metabolite panels report probability of direction (pd) rather than significance, and
  metabolite–metabolite links are undirected partial correlations.
- **Fit assessment:** because the model is near-saturated at n = 24, approximate SEM fit
  indices (CFI/TLI/RMSEA/SRMR) are unstable and intentionally omitted; adequacy is judged by
  a posterior-predictive p-value (on centroid separation) and PSIS-LOO instead.
- **Reference posterior** (from the validated run, for sanity-checking your output): group
  separation ≈ 2.05 (95% CrI ~1.1–3.0, P(>1) ≈ 0.99), multivariate R² ≈ 0.25, max R-hat
  ≈ 1.00, PPP ≈ 0.57. Your exact numbers may differ slightly by Stan version/seed.
- `seed = 1` is set for the sampler; results are reproducible up to backend differences.

---

## Citation

If you use this code or data, please cite:

> *[Author(s), Year. Title. Journal.]*  <!-- TODO: fill in -->

## License

<!-- TODO: choose a license, e.g. MIT -->
