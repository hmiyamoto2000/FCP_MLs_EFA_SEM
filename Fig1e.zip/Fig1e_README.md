# Figure 1e — NMDS ordination of the whole gut microbiome

Code and data to reproduce **Figure 1e**: a Bray–Curtis **NMDS ordination** of the
whole-community gut microbiome across three host species (Fish, Chicken, Pig) and two
treatments (Control vs. Compost), together with the accompanying **PERMANOVA** tests.

The analysis is run in two steps — statistics in **R** (`vegan`), plotting in **Python**
(`matplotlib` / `seaborn`).

---

## Contents

| File | Description |
|------|-------------|
| `Fig1_2_dbRDA_varpart_final.R` | Main analysis. NMDS + PERMANOVA (and, if a chemistry table is supplied, dbRDA + variation partitioning). Writes results to `results_fig1/`. |
| `plot_ordination_animal_ggplottype.py` | Draws the ordination figure from an ordination-scores CSV. Colour = host species, marker/ellipse = treatment. |
| `list_whole.csv` | Sample metadata: `sample`, `cnd` (treatment), `env` (host species). |
| `Bacteria_whole_genus.csv` | Genus-level abundance table (samples × 388 genera). Used for Fig. 1e. |
| `Bacteria_whole_phylum.csv` | Phylum-level abundance table (samples × 17 phyla). Companion table at a coarser taxonomic level. |

**Groups.** `env` ∈ {Fish, Chicken, Pig}; `cnd` ∈ {`con` = Control, `Tst` = Compost}.
The first column of every abundance table is the sample ID and must match `sample` in
`list_whole.csv` (same order).

---

## Requirements

**R (≥ 4.0)**

```r
install.packages("vegan")
```

**Python (≥ 3.8)**

```bash
pip install pandas numpy matplotlib seaborn scipy
```

---

## Reproduce Figure 1e

### Step 1 — NMDS + PERMANOVA (R)

```bash
Rscript Fig1_2_dbRDA_varpart_final.R list_whole.csv Bacteria_whole_genus.csv
```

With two arguments the script runs in **NMDS + PERMANOVA** mode and creates a
`results_fig1/` directory containing, among others:

- `NMDS_scores.csv` — site scores (`NMDS1`, `NMDS2`) plus `species`, `treatment`, `stress` → **input for Fig. 1e**
- `adonis_species_treatment.csv` — PERMANOVA (species × treatment)
- `pairwise_species_permanova.csv` — pairwise species comparisons
- `Fig1_summary.txt` — human-readable summary of the statistics

### Step 2 — Plot the ordination (Python)

```bash
python plot_ordination_animal_ggplottype.py results_fig1/NMDS_scores.csv NMDS1 NMDS2
```

This writes the figure to `ordination_output/NMDS_scores.pdf` and `.png`.
Host species are distinguished by colour (Fish = blue, Chicken = red, Pig = green),
treatments by marker and ellipse style (Control = open marker / dashed ellipse,
Compost = filled marker / solid ellipse). The NMDS stress value, if present in the CSV,
is shown in the title.

> To plot the phylum level instead, run Step 1 with `Bacteria_whole_phylum.csv` and
> re-run Step 2 on the resulting `NMDS_scores.csv`.

---

## Input data format

`list_whole.csv`

```
sample,cnd,env
FE_control_1,con,Fish
FE_control_2,con,Fish
...
```

`Bacteria_whole_genus.csv` (relative abundances; first column = sample ID)

```
sample,g_D_5__Lactobacillus,g_D_5__Escherichia-Shigella,...
FE_control_1,5.97,0,...
...
```

The plotting script accepts either the R output column names (`sample_id` / `species` /
`treatment`) or the short names (`name` / `env` / `cnd`); it maps them automatically.

---

## Notes

- `set.seed(123)` is set before `metaMDS()`, so the NMDS is reproducible run-to-run.
- The genus table is used **as-is** (no filtering or transformation), matching the
  original analysis.
- Supplying a third argument (a chemistry table) switches the R script into
  **dbRDA + variation partitioning** mode (used for other panels / Fig. 2); it is not
  needed for Fig. 1e.

---

