# Figure 2 — dbRDA & Variation Partitioning (microbiome × metabolome)

Code and data to reproduce **Figure 2**: a joint analysis of the gut microbiome and the
metabolome across three host species (Fish, Chicken, Pig) and two treatments
(Control vs. Compost). It produces a **distance-based RDA (dbRDA)** ordination and a
**variation partitioning** of how much community variation is explained by
Species, Treatment, and the paired -omics block (Metabolite or Microbiome).

The pipeline has three stages: **transform metabolites (Python) → statistics (R, `vegan`)
→ figures (Python)**.

---

## Contents

| File | Role |
|------|------|
| `List.csv` | Sample metadata: `sample`, `cnd` (treatment), `env` (host species). 24 samples, balanced (4 per species × treatment). |
| `B_Genus_bacdata.csv` | Genus-level microbiome table (samples × 207 genera). |
| `Chemical_data.csv` | Raw metabolite table (samples × 339 compounds). |
| `metabolite_transform.py` | Transforms the metabolite table (log → z-score) and writes `*_log_Z` columns required by the R scripts. |
| `Fig2_dbRDA_varpart_fixed.R` | Main analysis: NMDS + PERMANOVA + dbRDA (forward selection) + variation partitioning. |
| `permanova_treatment.R` | Supplementary PERMANOVA (Species / Treatment R², pseudo-F, p) for both microbiome and metabolome. |
| `plot_ordination_animal_fixnew.py` | Draws the dbRDA / NMDS ordination. Colour = host species, marker/ellipse = treatment. |
| `Variation_Venn_animal_fixed.py` | Draws the variation-partitioning Venn diagram and bar chart. |

**Groups.** `env` ∈ {Fish, Chicken, Pig}; `cnd` ∈ {`con` = Control, `Tst` = Compost}.
The first column of every data table is the sample ID and must be in the **same order**
as `List.csv`.

---

## Requirements

**R (≥ 4.0)**

```r
install.packages("vegan")
```

**Python (≥ 3.8)**

```bash
pip install pandas numpy matplotlib seaborn scipy matplotlib-venn
```

---

## Reproduce Figure 2

### Step 0 — Transform metabolites (Python)

Convert the raw metabolite table to log → z-score (`*_log_Z` columns), which the R
scripts expect. Values ≤ 0 are replaced by (min positive in that column)/2 before the
natural log; a Shapiro–Wilk normality report is written alongside the output.

```bash
python metabolite_transform.py Chemical_data.csv chem_log_Z.csv --mode log_Z
```

Outputs: `chem_log_Z.csv` and `shapiro_results.txt`.

### Step 1 — dbRDA + Variation Partitioning (R)

Response = microbiome (Bray–Curtis). Species, Treatment and the metabolite block
explain microbiome composition:

```bash
Rscript Fig2_dbRDA_varpart_fixed.R List.csv B_Genus_bacdata.csv chem_log_Z.csv --response microbiome
```

Results are written to `results_vp_microbiome/`, including:

- `NMDS_scores.csv` — NMDS site scores (`NMDS1`, `NMDS2`)
- `dbRDA_sites.csv` — dbRDA site scores (`CAP1`, `CAP2`) → **ordination panel data**
- `dbRDA_vectors.csv`, `dbRDA_variance.csv`, `dbRDA_statistics.txt`
- `variation_partitioning.pdf` + `vp_variance.csv` → **Venn / bar panel data**
- `adonis_species_treatment.csv`, `pairwise_species_permanova.csv`
- `Fig1_summary.txt` — statistics summary

> **Optional (reciprocal view).** Swap the response to the metabolome (Euclidean) with
> the same command, only changing the flag:
> ```bash
> Rscript Fig2_dbRDA_varpart_fixed.R List.csv B_Genus_bacdata.csv chem_log_Z.csv --response metabolite
> ```
> Results go to `results_vp_metabolite/`.

### Step 2 — Plot the ordination (Python)

```bash
# dbRDA
python plot_ordination_animal_fixnew.py results_vp_microbiome/dbRDA_sites.csv CAP1 CAP2

# or NMDS
python plot_ordination_animal_fixnew.py results_vp_microbiome/NMDS_scores.csv NMDS1 NMDS2
```

Figures are written to `ordination_output/` (PDF + PNG). Host species are distinguished
by colour (Fish = blue, Chicken = red, Pig = green); treatments by marker and ellipse
style (Control = open / dashed, Compost = filled / solid).

### Step 3 — Plot variation partitioning (Python)

```bash
python Variation_Venn_animal_fixed.py results_vp_microbiome/vp_variance.csv
```

Writes a Venn diagram, a bar chart, a combined figure, and a cleaned CSV to
`variation_partitioning_output/`. Negative adjusted R² values (a statistical artifact)
are clamped to 0 for display and flagged in the cleaned CSV. Figure size is adjustable
with `-w/--width` and `--height`.

### Supplementary — PERMANOVA table

Reports Species / Treatment R², pseudo-F and p for both the microbiome (Bray–Curtis) and
the metabolome (Euclidean), to show effects that are "small in R² but significant".

```bash
Rscript permanova_treatment.R List.csv B_Genus_bacdata.csv chem_log_Z.csv
```

Outputs go to `permanova_out/`.

---

## Method notes

- **Microbiome preprocessing (R):** genera present in fewer than 3 samples are removed,
  then converted to relative abundance (`decostand(method = "total")`); distances are
  Bray–Curtis.
- **Metabolite preprocessing:** log → standard z-score is done in Python
  (`metabolite_transform.py`), and the R scripts read the `*_log_Z` columns directly
  (with an in-R fallback if those columns are absent); distances are Euclidean.
- **dbRDA variable selection:** because metabolites (p ≈ 339) greatly outnumber samples
  (n = 24), explanatory variables are chosen by forward selection (`ordiR2step`) rather
  than fitting the saturated model.
- `set.seed(123)` is set before NMDS and the permutation tests, so results are
  reproducible.

---

