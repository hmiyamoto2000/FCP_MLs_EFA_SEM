# Figure 4 & Supplementary S10 — Bottom-up Cliff's delta analysis

Code and data for the **bottom-up (species-first) analysis** of the compost treatment
effect. Within each host species (Fish, Chicken, Pig), the Control vs. Compost difference
of every genus and metabolite is quantified with **Cliff's delta**; the three species are
then compared to find features that respond in the **same direction across species**, and
these are cross-classified against the **ELA state-defining factors**.

- **Figure 4** — main cross-species heatmap (key/universal factors) + Venn diagrams + ELA × Cliff cross-classification.
- **Supplementary S10** — the same heatmap showing *all* concordant factors.

> ⚠️ **Missing input — please add before running.** `bottomup_cliff_final.R` requires a
> 4th file, **`Chemical_Category_data.csv`** (metabolite-category abundance table, same
> sample rows as `List.csv`), which is **not included in this bundle**. Add it to the zip,
> or see "If you don't have the category table" below.

---

## Contents

| File | Role |
|------|------|
| `List.csv` | Sample metadata: `sample`, `cnd` (treatment), `env` (host species). 24 samples, balanced (4 per species × treatment). |
| `B_Genus_bacdata.csv` | Genus-level microbiome table (samples × 207 genera). |
| `Chemical_data.csv` | Raw metabolite table (samples × 339 compounds). |
| *`Chemical_Category_data.csv`* | **(required, not included)** metabolite-category abundance table. |
| `interactions_list_040625.csv` | ELA interaction edge list (`Name`, `Name`, `Value`). Node names drive the ★ ELA annotation. |
| `bottomup_cliff_final.R` | Main analysis: per-species Cliff's delta → cross-species direction classification → ELA cross-classification. |
| `plot_cliff_results_0_33_FIXED.py` | Draws the heatmaps, Venn diagrams and cross-classification bar charts from the R output. |
| `output_matabolite_log_Z.csv` | Pre-computed log→z metabolite table (`*_log_Z` columns), input for the supplementary PERMANOVA. |
| `metabolite_transform.py` | Regenerates `output_matabolite_log_Z.csv` from `Chemical_data.csv` if needed. |
| `permanova_treatment.R` | Supplementary PERMANOVA (Species / Treatment R², pseudo-F, p) for microbiome and metabolome. |

**Groups.** `env` ∈ {Fish, Chicken, Pig}; `cnd` ∈ {`con` = Control, `Tst` = Compost}.
The first column of every data table is the sample ID and must be in the **same order** as
`List.csv`.

---

## Requirements

**R (≥ 4.0)** — `bottomup_cliff_final.R` auto-installs `effsize` and `compositions` if
missing; `permanova_treatment.R` needs `vegan`.

```r
install.packages(c("effsize", "compositions", "vegan"))
```

**Python (≥ 3.8)**

```bash
pip install pandas numpy matplotlib seaborn scipy matplotlib-venn
```

---

## Reproduce Figure 4 & S10

### Step 1 — Cliff's delta analysis (R)

```bash
Rscript bottomup_cliff_final.R \
  List.csv B_Genus_bacdata.csv Chemical_data.csv Chemical_Category_data.csv \
  interactions_list_040625.csv
```

The 5th argument (the ELA edge list) is optional but needed for the ★ annotation and the
cross-classification panel. Results are written to `results_final/`, including:

- `Step1_<Species>_cliff_microbiome.csv` / `_metabolites.csv` / `_categories.csv` — per-species effects (→ Supplementary)
- `Step2_cross_species_microbiome.csv` / `_metabolites.csv` — cross-species table with ELA annotation (**input for the Python figures**)
- `Step2_heatmap_*.pdf`, `Step2_venn_*.pdf`, `Step3_cross_classification.pdf` — quick R-drawn versions
- `Step3_paper_table_*.csv` — summary tables

**Effect threshold.** A feature is called responsive at |δ| ≥ 0.474 (medium effect);
concordance requires ≥ 2 species responding in the same direction.

### Step 2 — Main figure, Figure 4 (Python)

Filtered "key factors" view (3-species concordant + ELA factors + universally medium):

```bash
python plot_cliff_results_0_33_FIXED.py results_final/ \
  --ela interactions_list_040625.csv \
  --concordant_only --collapse_rare --key_only
```

Writes to `cliff_figures/`: `Fig4_combined_heatmap.pdf/png`, the Venn diagrams
(`venn_micro_*`, `venn_metab_*`) and `cross_classification.pdf/png`.

### Step 3 — Supplementary S10 (Python)

Same analysis showing all concordant factors (drop `--key_only`, use a separate output
directory):

```bash
python plot_cliff_results_0_33_FIXED.py results_final/ \
  --ela interactions_list_040625.csv \
  --concordant_only --collapse_rare \
  --outdir cliff_figures_supplementary
```

**Useful flags:** `--concordant_only` (exclude MIXED), `--collapse_rare` (merge
identical-pattern rare genera into one row), `--key_only` (main-figure subset),
`--min_delta <x>` (minimum |mean δ| to display).

### Supplementary — PERMANOVA table (R)

```bash
Rscript permanova_treatment.R List.csv B_Genus_bacdata.csv output_matabolite_log_Z.csv
```

Outputs to `permanova_out/`. (Regenerate the log→z table if needed with
`python metabolite_transform.py Chemical_data.csv output_matabolite_log_Z.csv --mode log_Z`.)

---

## Method notes

- **Microbiome:** zeros replaced by 0.5, then CLR transform (`compositions::clr`).
- **Metabolites / categories:** `log1p` transform.
- **Cliff's delta** is computed per species as Compost (`Tst`) vs. Control (`con`),
  so a positive δ means the feature increases under compost.
- **ELA matching** strips the `G_` / `M_` prefixes and matches feature names to ELA node
  names case-insensitively; matched features are marked ★.
- The R script's internal comments/labels say "Fig.3" — this is legacy numbering; the
  current manuscript figure is **Fig.4** (with **S10** as its all-factor supplement).

### If you don't have the category table

`Chemical_Category_data.csv` is only used for the `Step1_*_cliff_categories.csv` outputs;
the heatmaps, Venn diagrams and cross-classification (Fig.4 / S10) rely on the genus and
metabolite tables. If the category table is unavailable, a minimal workaround is to pass a
copy of `Chemical_data.csv` as the 4th argument (the category CSVs will then be
uninformative but the main figures are unaffected). Prefer adding the real table when
possible.

---

